# Veynote — Will & Inheritance Workspace Upgrade

## What was diagnosed

The structured `WillInheritance.jsx` calls `GET /api/will`, while the original backend only exposed the legacy `GET /api/notes/will/document` route. That makes the structured page fail with a 404 unless the new Will router is deployed.

The original `server/src/index.js` also contained a duplicate `const cors = require("cors")` declaration. Node cannot start with that syntax error, which can surface to the browser as a 503 from the API host.

The new implementation fixes both issues and keeps the existing Will vault architecture.

## Files to copy

### Frontend — replace/add

- `client/src/pages/notes/WillInheritance.jsx` — replace
- `client/src/pages/notes/WillRecordDetail.jsx` — add
- `client/src/pages/notes/WillDetail.jsx` — add
- `client/src/pages/notes/WillAssetDetail.jsx` — add
- `client/src/pages/notes/WillBeneficiaryDetail.jsx` — add
- `client/src/pages/notes/WillContactDetail.jsx` — add
- `client/src/pages/notes/WillExecutorDetail.jsx` — add
- `client/src/components/will/WillModal.jsx` — add
- `client/src/components/will/WillSection.jsx` — add
- `client/src/components/will/CompletionCard.jsx` — add
- `client/src/components/will/WillForms.jsx` — add
- `client/src/components/will/DeleteConfirmation.jsx` — add
- `client/src/components/will/WillDocuments.jsx` — add
- `client/src/api/will.js` — add
- `client/src/api/client.js` — replace with the supplied version (improves API/upload error metadata)
- `client/src/App.jsx` — replace with the supplied version (adds `/will` and detail routes while preserving `/notes/will` via redirect)

### Backend — replace/add

- `server/src/routes/will.routes.js` — add
- `server/src/index.js` — replace with the supplied version (fixes duplicate CORS declaration and mounts `/api/will`)
- `server/prisma/schema.prisma` — replace with the supplied version
- `server/prisma/migrations/20260908124500_will_inheritance_form/migration.sql` — add/keep
- `server/prisma/migrations/20260909000100_will_workspace_upgrade/migration.sql` — add

## Backend capabilities added

- Will dashboard
- Multiple Will details
- Unlimited assets
- Unlimited beneficiaries
- Unlimited important contacts
- Multiple executors / personal representatives
- Digital legacy detail type
- Supporting documents
- Secure Will document download through an authenticated + Will-vault-gated endpoint
- Activity/audit history
- Search/filter/sort support on the client
- Detail endpoints for every major record
- Ownership checks on every record operation

## API surface

All `/api/will/*` endpoints require the normal account Bearer token and a valid `X-Will-Token`.

### Dashboard
- `GET /api/will`
- `PATCH /api/will`

### Details
- `GET /api/will/details/:id`
- `POST /api/will/details`
- `PATCH /api/will/details/:id`
- `DELETE /api/will/details/:id`

### Assets
- `GET /api/will/assets/:id`
- `POST /api/will/assets`
- `PATCH /api/will/assets/:id`
- `DELETE /api/will/assets/:id`

### Beneficiaries
- `GET /api/will/beneficiaries/:id`
- `POST /api/will/beneficiaries`
- `PATCH /api/will/beneficiaries/:id`
- `DELETE /api/will/beneficiaries/:id`

### Contacts
- `GET /api/will/contacts/:id`
- `POST /api/will/contacts`
- `PATCH /api/will/contacts/:id`
- `DELETE /api/will/contacts/:id`

### Executors
- `GET /api/will/executors/:id`
- `POST /api/will/executors`
- `PATCH /api/will/executors/:id`
- `DELETE /api/will/executors/:id`

### Documents
- `GET /api/will/documents`
- `POST /api/will/documents` (multipart field: `file`; optional `scopeType` + `scopeId`)
- `GET /api/will/documents/:id/file`
- `DELETE /api/will/documents/:id`

### Activity
- `GET /api/will/activity`

## Deployment order

1. Back up the MySQL database.
2. Deploy the backend files and both migrations.
3. Run `npx prisma migrate deploy` in the server directory.
4. Run `npx prisma generate`.
5. Restart the Node.js application.
6. Deploy the frontend files.
7. Verify `GET /api/health` returns 200.
8. Log in, open Will & Inheritance, unlock the Will vault, then create one detail, asset and beneficiary as a smoke test.

The second migration expects the first Will migration to have been applied first. Both migration directories are included in this package so a fresh deployment can apply them in order.

## Important security note

Will documents are stored under `server/private-will`, not the existing public `/uploads` directory. They are served only through `/api/will/documents/:id/file`, which requires account authentication and a valid Will vault token.

Do not put raw passwords, private keys, seed phrases or authentication secrets into Will detail fields. Use the application's secure credential/vault architecture for secrets.
