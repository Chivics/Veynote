import WillModal from "./WillModal";

export default function DeleteConfirmation({ open, title, message, busy, onCancel, onConfirm }) {
  return (
    <WillModal open={open} title={title || "Delete record?"} description="This action cannot be undone." onClose={onCancel}>
      <p className="text-[12px] text-ink-soft leading-relaxed">{message}</p>
      <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 mt-6">
        <button type="button" className="btn-outline" onClick={onCancel} disabled={busy}>Cancel</button>
        <button type="button" className="btn-primary bg-danger border-danger" onClick={onConfirm} disabled={busy}>{busy ? "Deleting…" : "Delete"}</button>
      </div>
    </WillModal>
  );
}
