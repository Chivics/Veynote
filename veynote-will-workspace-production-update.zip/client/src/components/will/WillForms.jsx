import { useEffect, useState } from "react";
import { Field } from "./WillSection";

const DETAIL_TYPES = [
  ["personal-wishes", "Personal Wishes"],
  ["funeral-wishes", "Funeral Wishes"],
  ["medical-preferences", "Medical Preferences"],
  ["digital-legacy", "Digital Legacy"],
  ["important-instructions", "Important Instructions"],
  ["family-message", "Family Message"],
  ["executor-information", "Executor Information"],
  ["guardian-information", "Guardian Information"],
  ["special-requests", "Special Requests"],
  ["other", "Other"],
];
const ASSET_TYPES = ["Property", "Bank Account", "Investment", "Vehicle", "Business", "Cryptocurrency", "Jewellery", "Personal Valuables", "Insurance", "Intellectual Property", "Digital Asset", "Other"];
const BENEFICIARY_TYPES = ["Person", "Organisation", "Charity", "Trust", "Other"];
const CONTACT_TYPES = ["Lawyer", "Executor", "Family Member", "Financial Adviser", "Accountant", "Doctor", "Insurance Contact", "Other"];

export const EMPTY_DETAIL = { type: "personal-wishes", title: "", content: "" };
export const EMPTY_ASSET = { name: "", type: "Property", description: "", estimatedValue: "", location: "", accountReference: "", ownership: "", instructions: "" };
export const EMPTY_BENEFICIARY = { name: "", beneficiaryType: "Person", relationship: "", contact: "", allocation: "", specificEntitlement: "", specificAssetId: "", notes: "", specialInstructions: "" };
export const EMPTY_CONTACT = { name: "", type: "Other", phone: "", email: "", notes: "" };
export const EMPTY_EXECUTOR = { name: "", relationship: "", contact: "", address: "", notes: "", instructions: "" };

function Input({ value, onChange, ...props }) {
  return <input className="input" value={value} onChange={(e) => onChange(e.target.value)} {...props} />;
}

export function WillDetailForm({ initial = EMPTY_DETAIL, onSubmit, onCancel, busy }) {
  const [form, setForm] = useState(initial);
  useEffect(() => setForm(initial), [initial]);
  const set = (key, value) => setForm((v) => ({ ...v, [key]: value }));
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(form); }} className="grid gap-4">
      <Field label="Detail type" required><select className="input" value={form.type} onChange={(e) => set("type", e.target.value)}>{DETAIL_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
      <Field label="Title" required><Input value={form.title} onChange={(v) => set("title", v)} placeholder="e.g. Funeral wishes" autoFocus /></Field>
      <Field label="Details / instructions" required hint="Keep passwords and authentication secrets out of ordinary Will fields."><textarea className="input min-h-[180px] resize-y" value={form.content} onChange={(e) => set("content", e.target.value)} placeholder="Write the details you want to preserve…" /></Field>
      <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 pt-2"><button type="button" className="btn-outline" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save detail"}</button></div>
    </form>
  );
}

export function AssetForm({ initial = EMPTY_ASSET, onSubmit, onCancel, busy }) {
  const [form, setForm] = useState(initial);
  useEffect(() => setForm(initial), [initial]);
  const set = (key, value) => setForm((v) => ({ ...v, [key]: value }));
  const isFinancial = ["Bank Account", "Investment", "Insurance", "Cryptocurrency"].includes(form.type);
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(form); }} className="grid gap-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Asset type" required><select className="input" value={form.type} onChange={(e) => set("type", e.target.value)}>{ASSET_TYPES.map((v) => <option key={v}>{v}</option>)}</select></Field>
        <Field label="Asset name" required><Input value={form.name} onChange={(v) => set("name", v)} placeholder="e.g. House in Lagos" autoFocus /></Field>
      </div>
      <Field label="Description"><textarea className="input min-h-[90px] resize-y" value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="What should someone know about this asset?" /></Field>
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Estimated value"><Input value={form.estimatedValue} onChange={(v) => set("estimatedValue", v)} placeholder="e.g. ₦25,000,000" /></Field>
        <Field label={isFinancial ? "Account / reference information" : "Location / where it is held"}><Input value={isFinancial ? form.accountReference : form.location} onChange={(v) => set(isFinancial ? "accountReference" : "location", v)} placeholder={isFinancial ? "Use a safe reference, not a password" : "e.g. Lagos, Nigeria"} /></Field>
      </div>
      {isFinancial && <Field label="Location / institution"><Input value={form.location} onChange={(v) => set("location", v)} placeholder="e.g. Bank or investment institution" /></Field>}
      <Field label="Ownership information"><Input value={form.ownership} onChange={(v) => set("ownership", v)} placeholder="e.g. Sole owner / joint ownership" /></Field>
      <Field label="Instructions"><textarea className="input min-h-[120px] resize-y" value={form.instructions} onChange={(e) => set("instructions", e.target.value)} placeholder="What should happen with this asset?" /></Field>
      <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 pt-2"><button type="button" className="btn-outline" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save asset"}</button></div>
    </form>
  );
}

export function BeneficiaryForm({ initial = EMPTY_BENEFICIARY, assets = [], onSubmit, onCancel, busy }) {
  const [form, setForm] = useState(initial);
  useEffect(() => setForm(initial), [initial]);
  const set = (key, value) => setForm((v) => ({ ...v, [key]: value }));
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(form); }} className="grid gap-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Beneficiary type" required><select className="input" value={form.beneficiaryType} onChange={(e) => set("beneficiaryType", e.target.value)}>{BENEFICIARY_TYPES.map((v) => <option key={v}>{v}</option>)}</select></Field>
        <Field label="Full name / organisation" required><Input value={form.name} onChange={(v) => set("name", v)} placeholder="e.g. John Doe" autoFocus /></Field>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Relationship"><Input value={form.relationship} onChange={(v) => set("relationship", v)} placeholder="e.g. Daughter" /></Field>
        <Field label="Contact"><Input value={form.contact} onChange={(v) => set("contact", v)} placeholder="Phone or email" /></Field>
      </div>
      <Field label="Allocation / entitlement" hint="You can describe a percentage, fixed amount, share, or other entitlement."><textarea className="input min-h-[90px] resize-y" value={form.allocation} onChange={(e) => set("allocation", e.target.value)} placeholder="e.g. 50% of the estate" /></Field>
      {assets.length > 0 && <Field label="Specific asset"><select className="input" value={form.specificAssetId} onChange={(e) => set("specificAssetId", e.target.value)}><option value="">No specific asset</option>{assets.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></Field>}
      <Field label="Specific entitlement"><textarea className="input min-h-[80px] resize-y" value={form.specificEntitlement} onChange={(e) => set("specificEntitlement", e.target.value)} placeholder="e.g. The family house and its contents" /></Field>
      <Field label="Notes"><textarea className="input min-h-[80px] resize-y" value={form.notes} onChange={(e) => set("notes", e.target.value)} /></Field>
      <Field label="Special instructions"><textarea className="input min-h-[100px] resize-y" value={form.specialInstructions} onChange={(e) => set("specialInstructions", e.target.value)} /></Field>
      <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 pt-2"><button type="button" className="btn-outline" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save beneficiary"}</button></div>
    </form>
  );
}

export function ContactForm({ initial = EMPTY_CONTACT, onSubmit, onCancel, busy }) {
  const [form, setForm] = useState(initial);
  useEffect(() => setForm(initial), [initial]);
  const set = (key, value) => setForm((v) => ({ ...v, [key]: value }));
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(form); }} className="grid gap-4">
      <div className="grid sm:grid-cols-2 gap-4"><Field label="Contact type" required><select className="input" value={form.type} onChange={(e) => set("type", e.target.value)}>{CONTACT_TYPES.map((v) => <option key={v}>{v}</option>)}</select></Field><Field label="Name" required><Input value={form.name} onChange={(v) => set("name", v)} placeholder="Full name" autoFocus /></Field></div>
      <div className="grid sm:grid-cols-2 gap-4"><Field label="Phone"><Input value={form.phone} onChange={(v) => set("phone", v)} /></Field><Field label="Email"><Input type="email" value={form.email} onChange={(v) => set("email", v)} /></Field></div>
      <Field label="Notes"><textarea className="input min-h-[120px] resize-y" value={form.notes} onChange={(e) => set("notes", e.target.value)} /></Field>
      <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 pt-2"><button type="button" className="btn-outline" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save contact"}</button></div>
    </form>
  );
}

export function ExecutorForm({ initial = EMPTY_EXECUTOR, onSubmit, onCancel, busy }) {
  const [form, setForm] = useState(initial);
  useEffect(() => setForm(initial), [initial]);
  const set = (key, value) => setForm((v) => ({ ...v, [key]: value }));
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(form); }} className="grid gap-4">
      <div className="grid sm:grid-cols-2 gap-4"><Field label="Full name" required><Input value={form.name} onChange={(v) => set("name", v)} placeholder="Executor / personal representative" autoFocus /></Field><Field label="Relationship"><Input value={form.relationship} onChange={(v) => set("relationship", v)} /></Field></div>
      <Field label="Contact"><Input value={form.contact} onChange={(v) => set("contact", v)} placeholder="Phone or email" /></Field>
      <Field label="Address"><textarea className="input min-h-[90px] resize-y" value={form.address} onChange={(e) => set("address", e.target.value)} /></Field>
      <Field label="Notes"><textarea className="input min-h-[90px] resize-y" value={form.notes} onChange={(e) => set("notes", e.target.value)} /></Field>
      <Field label="Instructions"><textarea className="input min-h-[120px] resize-y" value={form.instructions} onChange={(e) => set("instructions", e.target.value)} /></Field>
      <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 pt-2"><button type="button" className="btn-outline" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save executor"}</button></div>
    </form>
  );
}

export function WillProfileForm({ initialTitle, onSubmit, onCancel, busy }) {
  const [title, setTitle] = useState(initialTitle || "My Will & Inheritance");
  useEffect(() => setTitle(initialTitle || "My Will & Inheritance"), [initialTitle]);
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit({ title }); }} className="grid gap-4">
      <Field label="Document title" required><Input value={title} onChange={setTitle} placeholder="My Will & Inheritance" autoFocus /></Field>
      <div className="flex flex-col-reverse sm:flex-row justify-end gap-2"><button type="button" className="btn-outline" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save title"}</button></div>
    </form>
  );
}
