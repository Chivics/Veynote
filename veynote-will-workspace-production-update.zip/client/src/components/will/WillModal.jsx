import { useEffect } from "react";

export default function WillModal({ open, title, description, onClose, children, wide = false }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" aria-label="Close dialog" onClick={onClose} className="absolute inset-0 bg-black/45" />
      <div className={`relative w-full ${wide ? "max-w-2xl" : "max-w-xl"} max-h-[92vh] overflow-y-auto bg-app-panel border border-app-border rounded-t-2xl sm:rounded-2xl shadow-2xl`}>
        <div className="sticky top-0 z-10 bg-app-panel/95 backdrop-blur border-b border-app-border px-4 sm:px-6 py-4 flex items-start justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-[16px] font-bold truncate">{title}</h2>
            {description && <p className="text-[11px] text-ink-muted mt-1">{description}</p>}
          </div>
          <button type="button" onClick={onClose} className="text-ink-muted hover:text-ink text-xl leading-none p-1" aria-label="Close">×</button>
        </div>
        <div className="p-4 sm:p-6">{children}</div>
      </div>
    </div>
  );
}
