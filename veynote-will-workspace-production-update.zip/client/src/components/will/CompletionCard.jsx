export default function CompletionCard({ items }) {
  const complete = items.filter((item) => item.complete).length;
  const percent = Math.round((complete / items.length) * 100);
  return (
    <section className="card p-4 sm:p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <span className="eyebrow">COMPLETION</span>
          <p className="text-[12px] font-semibold mt-2">{complete} of {items.length} areas complete</p>
        </div>
        <strong className="text-[20px]">{percent}%</strong>
      </div>
      <div className="h-2 rounded-full bg-app-panel2 border border-app-border overflow-hidden mt-4">
        <div className="h-full bg-accent-notes rounded-full transition-all" style={{ width: `${percent}%` }} />
      </div>
      <div className="grid sm:grid-cols-2 gap-2 mt-4">
        {items.map((item) => (
          <div key={item.key} className="flex items-start gap-2 text-[10.5px]">
            <span className={item.complete ? "text-accent-notes" : "text-ink-muted"}>{item.complete ? "✓" : "○"}</span>
            <div className="min-w-0">
              <p className="font-semibold">{item.label}</p>
              {!item.complete && <p className="text-ink-muted mt-0.5">{item.help}</p>}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
