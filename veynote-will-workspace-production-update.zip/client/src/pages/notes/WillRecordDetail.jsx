import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import VaultGate from "../../components/VaultGate";
import { clearVaultToken, getVaultToken } from "../../utils/vault";
import { willApi } from "../../api/will";
import WillModal from "../../components/will/WillModal";
import DeleteConfirmation from "../../components/will/DeleteConfirmation";
import WillDocuments from "../../components/will/WillDocuments";
import { AssetForm, BeneficiaryForm, ContactForm, EMPTY_ASSET, EMPTY_BENEFICIARY, EMPTY_CONTACT, EMPTY_DETAIL, EMPTY_EXECUTOR, ExecutorForm, WillDetailForm } from "../../components/will/WillForms";

const CONFIG = {
  detail: { label: "Will Detail", singular: "detail", api: willApi.details, back: "/will" },
  asset: { label: "Asset", singular: "asset", api: willApi.assets, back: "/will" },
  beneficiary: { label: "Beneficiary", singular: "beneficiary", api: willApi.beneficiaries, back: "/will" },
  contact: { label: "Important Contact", singular: "contact", api: willApi.contacts, back: "/will" },
  executor: { label: "Executor", singular: "executor", api: willApi.executors, back: "/will" },
};

function Field({ label, value }) {
  if (!value) return null;
  return <div className="rounded-lg border border-app-border bg-app-panel2 p-3"><p className="text-[9.5px] uppercase tracking-[.08em] font-bold text-ink-muted">{label}</p><p className="text-[11.5px] text-ink-soft mt-1 whitespace-pre-wrap break-words">{value}</p></div>;
}
function date(value) { return value ? new Intl.DateTimeFormat(undefined, { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(value)) : "—"; }

export default function WillRecordDetail({ kind }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const config = CONFIG[kind];
  const [unlocked, setUnlocked] = useState(Boolean(getVaultToken("will")));
  const [record, setRecord] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [relatedAssets, setRelatedAssets] = useState([]);

  const load = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const key = kind === "detail" ? "detail" : kind;
      const response = await config.api.get(id);
      setRecord(response[key]);
      if (kind === "beneficiary") {
        try {
          const dashboard = await willApi.get();
          setRelatedAssets(dashboard.will?.assets || []);
        } catch (assetErr) {
          console.warn("[WillRecordDetail:beneficiary] related assets unavailable", assetErr);
        }
      }
      setUnlocked(true);
    } catch (err) {
      console.error(`[WillRecordDetail:${kind}] load failed`, err);
      if (err.requiresVault) { clearVaultToken("will"); setUnlocked(false); setRecord(null); }
      else setError(err.message || `We couldn't load this ${config.singular}.`);
    } finally { setLoading(false); }
  }, [config.api, config.singular, id, kind]);

  useEffect(() => { if (unlocked) load(); }, [unlocked, load]);

  async function save(form) {
    setBusy(true); setError("");
    try {
      const key = kind === "detail" ? "detail" : kind;
      const response = await config.api.update(id, form);
      setRecord(response[key]); setModalOpen(false);
    } catch (err) { console.error(`[WillRecordDetail:${kind}] update failed`, err); setError(err.message || `We couldn't update this ${config.singular}.`); }
    finally { setBusy(false); }
  }

  async function remove() {
    setBusy(true); setError("");
    try { await config.api.remove(id); navigate(config.back, { replace: true }); }
    catch (err) { console.error(`[WillRecordDetail:${kind}] delete failed`, err); setError(err.message || `We couldn't delete this ${config.singular}.`); setBusy(false); setDeleteOpen(false); }
  }

  if (!unlocked) return <div className="max-w-[620px] mx-auto"><div className="mb-7"><span className="eyebrow">PRIVATE & SENSITIVE</span><h1 className="text-[30px] font-bold mt-1.5">Will & Inheritance</h1></div><VaultGate vault="will" onUnlock={() => { setUnlocked(true); load(); }} /></div>;
  if (loading && !record) return <div className="max-w-[900px] mx-auto py-8"><p className="text-ink-muted text-[12px]">Loading {config.singular}…</p></div>;
  if (!record) return <div className="max-w-[900px] mx-auto"><p className="text-danger text-[12px]">{error || `We couldn't find this ${config.singular}.`}</p><Link to="/will" className="btn-outline inline-block mt-4">Back to Will</Link></div>;

  const formInitial = kind === "detail" ? { type: record.type, title: record.title, content: record.content } : kind === "asset" ? { ...EMPTY_ASSET, ...record } : kind === "beneficiary" ? { ...EMPTY_BENEFICIARY, ...record } : kind === "contact" ? { ...EMPTY_CONTACT, ...record } : { ...EMPTY_EXECUTOR, ...record };
  const title = record.title || record.name;
  const docs = record.documents || [];

  return (
    <div className="max-w-[900px] mx-auto pb-10">
      <div className="flex flex-wrap items-center gap-2 mb-5"><Link to="/will" className="text-[10.5px] font-semibold text-accent-notes">← Back to Will</Link><span className="text-ink-muted">/</span><span className="text-[10.5px] text-ink-muted">{config.label}</span></div>
      {error && <div className="rounded-xl border border-danger/30 bg-danger/5 px-3.5 py-3 mb-4 text-[11px] text-danger">{error}</div>}
      <header className="mb-5"><span className="eyebrow">{record.type?.replaceAll("-", " ") || config.label}</span><h1 className="text-[26px] sm:text-[30px] font-bold tracking-tight mt-1.5 break-words">{title}</h1><p className="text-[10.5px] text-ink-muted mt-1">Created {date(record.createdAt)} · Updated {date(record.updatedAt)}</p></header>

      <div className="grid gap-4">
        <section className="card p-4 sm:p-6">
          <div className="grid sm:grid-cols-2 gap-2.5">
            {kind === "detail" && <Field label="Details" value={record.content} />}
            {kind === "asset" && <><Field label="Asset type" value={record.type} /><Field label="Estimated value" value={record.estimatedValue} /><Field label="Location" value={record.location} /><Field label="Account / reference" value={record.accountReference} /><Field label="Ownership" value={record.ownership} /><Field label="Description" value={record.description} /><Field label="Instructions" value={record.instructions} /></>}
            {kind === "beneficiary" && <><Field label="Beneficiary type" value={record.beneficiaryType} /><Field label="Relationship" value={record.relationship} /><Field label="Contact" value={record.contact} /><Field label="Allocation / entitlement" value={record.allocation} /><Field label="Specific asset" value={record.specificAsset?.name} /><Field label="Specific entitlement" value={record.specificEntitlement} /><Field label="Notes" value={record.notes} /><Field label="Special instructions" value={record.specialInstructions} /></>}
            {kind === "contact" && <><Field label="Type" value={record.type} /><Field label="Phone" value={record.phone} /><Field label="Email" value={record.email} /><Field label="Notes" value={record.notes} /></>}
            {kind === "executor" && <><Field label="Relationship" value={record.relationship} /><Field label="Contact" value={record.contact} /><Field label="Address" value={record.address} /><Field label="Notes" value={record.notes} /><Field label="Instructions" value={record.instructions} /></>}
          </div>
          <div className="flex flex-col sm:flex-row gap-2 mt-5 pt-4 border-t border-app-border"><button type="button" className="btn-primary" onClick={() => setModalOpen(true)}>Edit</button><button type="button" className="btn-outline text-danger" onClick={() => setDeleteOpen(true)}>Delete</button></div>
        </section>

        {(kind === "detail" || kind === "asset" || kind === "beneficiary") && <section className="card p-4 sm:p-6"><WillDocuments documents={docs} scopeType={kind} scopeId={id} onChange={(next) => setRecord((current) => ({ ...current, documents: next }))} /></section>}
      </div>

      <WillModal open={modalOpen} title={`Edit ${config.label}`} wide onClose={() => !busy && setModalOpen(false)}>
        {kind === "detail" && <WillDetailForm initial={formInitial} onSubmit={save} onCancel={() => setModalOpen(false)} busy={busy} />}
        {kind === "asset" && <AssetForm initial={formInitial} onSubmit={save} onCancel={() => setModalOpen(false)} busy={busy} />}
        {kind === "beneficiary" && <BeneficiaryForm initial={formInitial} assets={relatedAssets} onSubmit={save} onCancel={() => setModalOpen(false)} busy={busy} />}
        {kind === "contact" && <ContactForm initial={formInitial} onSubmit={save} onCancel={() => setModalOpen(false)} busy={busy} />}
        {kind === "executor" && <ExecutorForm initial={formInitial} onSubmit={save} onCancel={() => setModalOpen(false)} busy={busy} />}
      </WillModal>
      <DeleteConfirmation open={deleteOpen} title={`Delete ${config.label}?`} message={`Are you sure you want to remove “${title}”? This action cannot be undone.`} busy={busy} onCancel={() => !busy && setDeleteOpen(false)} onConfirm={remove} />
    </div>
  );
}
