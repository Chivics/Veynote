ALTER TABLE `WillAsset`
  ADD COLUMN `userId` VARCHAR(191) NULL,
  ADD COLUMN `type` VARCHAR(191) NOT NULL DEFAULT 'Other',
  ADD COLUMN `location` VARCHAR(191) NULL,
  ADD COLUMN `accountReference` VARCHAR(191) NULL,
  ADD COLUMN `ownership` VARCHAR(191) NULL;

ALTER TABLE `WillBeneficiary`
  ADD COLUMN `userId` VARCHAR(191) NULL,
  ADD COLUMN `beneficiaryType` VARCHAR(191) NOT NULL DEFAULT 'Person',
  ADD COLUMN `specificEntitlement` TEXT NULL,
  ADD COLUMN `specificAssetId` VARCHAR(191) NULL,
  ADD COLUMN `specialInstructions` TEXT NULL;


UPDATE `WillAsset` a
JOIN `Will` w ON w.id = a.willId
SET a.userId = w.userId;

UPDATE `WillBeneficiary` b
JOIN `Will` w ON w.id = b.willId
SET b.userId = w.userId;

ALTER TABLE `WillAsset` MODIFY COLUMN `userId` VARCHAR(191) NOT NULL;
ALTER TABLE `WillBeneficiary` MODIFY COLUMN `userId` VARCHAR(191) NOT NULL;

CREATE TABLE `WillDetail` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `willId` VARCHAR(191) NOT NULL,
  `type` VARCHAR(191) NOT NULL,
  `title` VARCHAR(191) NOT NULL,
  `content` LONGTEXT NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  INDEX `WillDetail_willId_idx`(`willId`),
  INDEX `WillDetail_userId_idx`(`userId`),
  INDEX `WillDetail_type_idx`(`type`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `WillContact` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `willId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `type` VARCHAR(191) NOT NULL DEFAULT 'Other',
  `phone` VARCHAR(191) NULL,
  `email` VARCHAR(191) NULL,
  `notes` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  INDEX `WillContact_willId_idx`(`willId`),
  INDEX `WillContact_userId_idx`(`userId`),
  INDEX `WillContact_type_idx`(`type`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `WillExecutor` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `willId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `relationship` VARCHAR(191) NULL,
  `contact` VARCHAR(191) NULL,
  `address` TEXT NULL,
  `notes` TEXT NULL,
  `instructions` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  INDEX `WillExecutor_willId_idx`(`willId`),
  INDEX `WillExecutor_userId_idx`(`userId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `WillDocument` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `willId` VARCHAR(191) NOT NULL,
  `detailId` VARCHAR(191) NULL,
  `assetId` VARCHAR(191) NULL,
  `beneficiaryId` VARCHAR(191) NULL,
  `originalName` VARCHAR(191) NOT NULL,
  `storedName` VARCHAR(191) NOT NULL,
  `mimeType` VARCHAR(191) NOT NULL,
  `sizeBytes` INT NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  INDEX `WillDocument_willId_idx`(`willId`),
  INDEX `WillDocument_userId_idx`(`userId`),
  INDEX `WillDocument_detailId_idx`(`detailId`),
  INDEX `WillDocument_assetId_idx`(`assetId`),
  INDEX `WillDocument_beneficiaryId_idx`(`beneficiaryId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `WillActivity` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `willId` VARCHAR(191) NOT NULL,
  `action` VARCHAR(191) NOT NULL,
  `entityType` VARCHAR(191) NOT NULL,
  `entityId` VARCHAR(191) NULL,
  `message` VARCHAR(191) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  INDEX `WillActivity_willId_createdAt_idx`(`willId`, `createdAt`),
  INDEX `WillActivity_userId_createdAt_idx`(`userId`, `createdAt`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `WillAsset`
  ADD INDEX `WillAsset_userId_idx`(`userId`),
  ADD INDEX `WillAsset_type_idx`(`type`);

ALTER TABLE `WillBeneficiary`
  ADD INDEX `WillBeneficiary_userId_idx`(`userId`),
  ADD INDEX `WillBeneficiary_specificAssetId_idx`(`specificAssetId`);

ALTER TABLE `WillAsset`
  ADD CONSTRAINT `WillAsset_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `WillBeneficiary`
  ADD CONSTRAINT `WillBeneficiary_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillBeneficiary_specificAssetId_fkey` FOREIGN KEY (`specificAssetId`) REFERENCES `WillAsset`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `WillDetail`
  ADD CONSTRAINT `WillDetail_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillDetail_willId_fkey` FOREIGN KEY (`willId`) REFERENCES `Will`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `WillContact`
  ADD CONSTRAINT `WillContact_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillContact_willId_fkey` FOREIGN KEY (`willId`) REFERENCES `Will`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `WillExecutor`
  ADD CONSTRAINT `WillExecutor_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillExecutor_willId_fkey` FOREIGN KEY (`willId`) REFERENCES `Will`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `WillDocument`
  ADD CONSTRAINT `WillDocument_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillDocument_willId_fkey` FOREIGN KEY (`willId`) REFERENCES `Will`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillDocument_detailId_fkey` FOREIGN KEY (`detailId`) REFERENCES `WillDetail`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillDocument_assetId_fkey` FOREIGN KEY (`assetId`) REFERENCES `WillAsset`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillDocument_beneficiaryId_fkey` FOREIGN KEY (`beneficiaryId`) REFERENCES `WillBeneficiary`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `WillActivity`
  ADD CONSTRAINT `WillActivity_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `WillActivity_willId_fkey` FOREIGN KEY (`willId`) REFERENCES `Will`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
