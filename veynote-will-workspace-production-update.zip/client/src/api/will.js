import { api } from "./client";

export const willApi = {
  get: () => api.get("/will"),
  update: (body) => api.patch("/will", body),

  details: {
    get: (id) => api.get(`/will/details/${id}`),
    create: (body) => api.post("/will/details", body),
    update: (id, body) => api.patch(`/will/details/${id}`, body),
    remove: (id) => api.delete(`/will/details/${id}`),
  },

  assets: {
    get: (id) => api.get(`/will/assets/${id}`),
    create: (body) => api.post("/will/assets", body),
    update: (id, body) => api.patch(`/will/assets/${id}`, body),
    remove: (id) => api.delete(`/will/assets/${id}`),
  },

  beneficiaries: {
    get: (id) => api.get(`/will/beneficiaries/${id}`),
    create: (body) => api.post("/will/beneficiaries", body),
    update: (id, body) => api.patch(`/will/beneficiaries/${id}`, body),
    remove: (id) => api.delete(`/will/beneficiaries/${id}`),
  },

  contacts: {
    get: (id) => api.get(`/will/contacts/${id}`),
    create: (body) => api.post("/will/contacts", body),
    update: (id, body) => api.patch(`/will/contacts/${id}`, body),
    remove: (id) => api.delete(`/will/contacts/${id}`),
  },

  executors: {
    get: (id) => api.get(`/will/executors/${id}`),
    create: (body) => api.post("/will/executors", body),
    update: (id, body) => api.patch(`/will/executors/${id}`, body),
    remove: (id) => api.delete(`/will/executors/${id}`),
  },

  documents: {
    list: () => api.get("/will/documents"),
    upload: (file, scopeType, scopeId, onProgress) =>
      api.upload("/will/documents", file, onProgress, { scopeType, scopeId }),
    remove: (id) => api.delete(`/will/documents/${id}`),
  },
};
