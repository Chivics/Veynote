CREATE TABLE `Will` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `title` VARCHAR(191) NOT NULL DEFAULT 'My Will & Inheritance',
  `wishes` LONGTEXT NULL,
  `instructions` LONGTEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE INDEX `Will_userId_key`(`userId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `WillAsset` (
  `id` VARCHAR(191) NOT NULL,
  `willId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `estimatedValue` VARCHAR(191) NULL,
  `instructions` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  INDEX `WillAsset_willId_idx`(`willId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `WillBeneficiary` (
  `id` VARCHAR(191) NOT NULL,
  `willId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `relationship` VARCHAR(191) NULL,
  `contact` VARCHAR(191) NULL,
  `allocation` TEXT NULL,
  `notes` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  INDEX `WillBeneficiary_willId_idx`(`willId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `Will`
  ADD CONSTRAINT `Will_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `WillAsset`
  ADD CONSTRAINT `WillAsset_willId_fkey` FOREIGN KEY (`willId`) REFERENCES `Will`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `WillBeneficiary`
  ADD CONSTRAINT `WillBeneficiary_willId_fkey` FOREIGN KEY (`willId`) REFERENCES `Will`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
