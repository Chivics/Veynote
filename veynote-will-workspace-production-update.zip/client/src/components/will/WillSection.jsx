import { Link } from "react-router-dom";

export function Field({ label, hint, required, children }) {
  return (
    <label className="block">
      <span className="block text-[10.5px] font-semibold text-ink-soft mb-1.5">
        {label}{required && <span className="text-danger"> *</span>}
      </span>
      {children}
      {hint && <span className="block text-[9.5px] text-ink-muted mt-1">{hint}</span>}
    </label>
  );
}

export function Section({ eyebrow, title, description, count, action, children }) {
  return (
    <section className="card p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-5">
        <div className="min-w-0">
          {eyebrow && <span className="eyebrow">{eyebrow}</span>}
          <div className="flex items-center flex-wrap gap-2 mt-1">
            <h2 className="text-[17px] font-bold">{title}</h2>
            {count !== undefined && <span className="chip">{count}</span>}
          </div>
          {description && <p className="text-[11.5px] text-ink-muted mt-1 max-w-2xl">{description}</p>}
        </div>
        {action && <div className="shrink-0">{action}</div>}
      </div>
      {children}
    </section>
  );
}

export function EmptyState({ title, description, action }) {
  return (
    <div className="rounded-xl border border-dashed border-app-border p-6 text-center">
      <p className="text-[12px] font-semibold">{title}</p>
      {description && <p className="text-[10.5px] text-ink-muted mt-1 max-w-md mx-auto">{description}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

export function RecordCard({ to, title, meta, description, badge, actions }) {
  return (
    <div className="rounded-xl border border-app-border bg-app-panel2 p-3.5 sm:p-4 hover:border-ink-muted/30 transition">
      <div className="flex items-start gap-3">
        <Link to={to} className="flex-1 min-w-0 block focus:outline-none">
          <div className="flex flex-wrap items-center gap-1.5 mb-1.5">
            {badge && <span className="chip">{badge}</span>}
            {meta && <span className="text-[10px] text-ink-muted">{meta}</span>}
          </div>
          <h3 className="text-[12.5px] font-bold truncate">{title}</h3>
          {description && <p className="text-[10.5px] text-ink-muted mt-1 line-clamp-2 whitespace-pre-wrap">{description}</p>}
          <span className="inline-block mt-2 text-[10.5px] font-semibold text-accent-notes">View details →</span>
        </Link>
        {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
      </div>
    </div>
  );
}
