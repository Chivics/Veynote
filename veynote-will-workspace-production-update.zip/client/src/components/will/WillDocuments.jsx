import { useRef, useState } from "react";
import { willApi } from "../../api/will";
import DeleteConfirmation from "./DeleteConfirmation";

function size(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function WillDocuments({ documents = [], scopeType, scopeId, onChange, compact = false }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [progress, setProgress] = useState(0);
  const [deleteId, setDeleteId] = useState(null);

  async function upload(event) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setBusy(true); setError(""); setProgress(0);
    try {
      const { document } = await willApi.documents.upload(file, scopeType, scopeId, setProgress);
      onChange?.([document, ...documents]);
    } catch (err) {
      console.error("[WillDocuments] upload failed", err);
      setError(err.message || "We couldn't upload that document.");
    } finally { setBusy(false); }
  }

  async function remove(id) {
    try {
      await willApi.documents.remove(id);
      onChange?.(documents.filter((item) => item.id !== id));
      setDeleteId(null);
    } catch (err) {
      console.error("[WillDocuments] delete failed", err);
      setError(err.message || "We couldn't remove that document.");
    }
  }

  return (
    <>
    <div>
      <div className="flex items-center justify-between gap-3 mb-3">
        <div><p className="text-[11.5px] font-bold">Documents</p><p className="text-[9.5px] text-ink-muted mt-0.5">{documents.length} {documents.length === 1 ? "file" : "files"}</p></div>
        <button type="button" className="btn-outline text-[10.5px]" onClick={() => inputRef.current?.click()} disabled={busy}>{busy ? `Uploading ${progress}%` : "+ Add document"}</button>
        <input ref={inputRef} type="file" className="hidden" onChange={upload} />
      </div>
      {error && <p className="text-danger text-[10.5px] mb-2">{error}</p>}
      {documents.length === 0 ? (
        !compact && <p className="text-[10.5px] text-ink-muted">No documents attached yet.</p>
      ) : (
        <div className="grid gap-2">
          {documents.map((doc) => (
            <div key={doc.id} className="flex items-center gap-3 rounded-lg border border-app-border bg-app-panel2 px-3 py-2.5">
              <span className="text-base">{doc.mimeType?.startsWith("image/") ? "🖼" : "📎"}</span>
              <div className="min-w-0 flex-1"><p className="text-[11px] font-semibold truncate">{doc.originalName}</p><p className="text-[9.5px] text-ink-muted">{doc.mimeType} · {size(doc.sizeBytes)}</p></div>
              <a href={doc.downloadUrl} target="_blank" rel="noreferrer" className="text-[10px] font-semibold text-accent-notes shrink-0">Open</a>
              <button type="button" onClick={() => setDeleteId(doc.id)} className="text-[10px] font-semibold text-danger shrink-0">Remove</button>
            </div>
          ))}
        </div>
      )}
    </div>
      <DeleteConfirmation open={Boolean(deleteId)} title="Remove document?" message="Are you sure you want to remove this document? This action cannot be undone." busy={false} onCancel={() => setDeleteId(null)} onConfirm={() => remove(deleteId)} />
    </>
  );
}
